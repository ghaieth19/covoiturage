<?php
session_start();

// Connexion à la base de données
$pdo = new PDO("mysql:host=localhost;dbname=covoiturage;charset=utf8mb4", "root", "");

// Initialiser un message d'erreur
$loginError = "";

// Traitement du formulaire
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'] ?? '';
    $motDePasse = $_POST['mot_de_passe'] ?? '';

    if ($email && $motDePasse) {
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ?");
        $stmt->execute([$email]);
        $utilisateur = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($utilisateur && isset($utilisateur['mot_de_passe']) && password_verify($motDePasse, $utilisateur['mot_de_passe'])) {
            $_SESSION['cin'] = $utilisateur['cin'];
            $_SESSION['email'] = $utilisateur['email'];
            header("Location: interface.php");
            exit();
        } else {
            $loginError = "Email ou mot de passe incorrect.";
        }
    } else {
        $loginError = "Veuillez remplir tous les champs.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion - Covoiturage</title>
    <style>
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #ffdf7d;
        }
        .login-box {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
            position: relative;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            background-color: #FFC107;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #FFD54F;
        }
        .options {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
        }
        .social-login {
            margin-top: 20px;
        }
        .social-icons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .social-icon {
            padding: 10px;
            border-radius: 5px;
            color: white;
            text-decoration: none;
        }
        .facebook {
            background-color: #3b5998;
        }
        .twitter {
            background-color: #1da1f2;
        }
        .create-account {
            margin-top: 20px;
        }
        .prev-link {
            position: absolute;
            top: 10px;
            left: 10px;
            text-decoration: none;
            color: #FFC107;
            font-size: 24px;
            font-weight: bold;
        }
        .prev-link:hover {
            color: #FFD54F;
        }
        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-box">
        <a href="acceuil.html" class="prev-link">&#8592;</a>
        <h2>Connexion</h2>
        <?php if ($loginError): ?>
            <div class="error-message"><?= htmlspecialchars($loginError) ?></div>
        <?php endif; ?>
        <form method="post" id="login-form">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Entrez votre email" required>
                <div class="error-message" id="email-error"></div>
            </div>
            <div class="form-group">
                <label for="mot_de_passe">Mot de passe</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="Entrez votre mot de passe" required>
                <div class="error-message" id="password-error"></div>
            </div>
            <button type="submit" class="btn">Se connecter <a href="interface.html"></a></button>
        </form>
        <div class="options">
            <label><input type="checkbox"> Se souvenir de moi</label>
            <a href="mot_de_passe_oublie.html">Mot de passe oublié ?</a>
        </div>
        <div class="social-login">
            <p>Ou se connecter avec :</p>
            <div class="social-icons">
                <a href="#" class="social-icon facebook">Facebook</a>
                <a href="#" class="social-icon twitter">Twitter</a>
            </div>
        </div>
        <div class="create-account">
            <p>Pas encore de compte ? <a href="ajouter_utilisateur.php">Créer un compte</a></p>
        </div>
    </div>
</div>

<script>
    document.getElementById('login-form').addEventListener('submit', function (event) {
        clearErrorMessages();

        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('mot_de_passe').value.trim();

        let isValid = true;

        if (!email) {
            showError('email-error', 'Veuillez entrer votre email.');
            isValid = false;
        }

        if (!password) {
            showError('password-error', 'Veuillez entrer votre mot de passe.');
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault();
        }
    });

    function showError(elementId, message) {
        document.getElementById(elementId).textContent = message;
    }

    function clearErrorMessages() {
        document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
    }
</script>
</body>
</html>
