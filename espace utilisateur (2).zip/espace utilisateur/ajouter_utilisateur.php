<?php
$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        // Connexion à la base de données
        $pdo = new PDO("mysql:host=localhost;dbname=covoiturage", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Dossier d'upload
        $uploadDir = __DIR__ . '/../uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Récupération des données
        $nom = $_POST['nom'] ?? '';
        $prenom = $_POST['prenom'] ?? '';
        $cin = $_POST['cin'] ?? '';
        $email = $_POST['email'] ?? '';
        $motdepasse = $_POST['motdepasse'] ?? '';
        $telephone = $_POST['telephone'] ?? '';
        $photo_pdp = $_FILES['photo_pdp'] ?? null;
        $photo_voiture = $_FILES['photo_voiture'] ?? null;

        // Traitement de la photo de profil (obligatoire)
        if ($photo_pdp && $photo_pdp['error'] === UPLOAD_ERR_OK) {
            $pdp_filename = uniqid() . "_" . basename($photo_pdp["name"]);
            $photo_pdp_path = $uploadDir . $pdp_filename;
            if (!move_uploaded_file($photo_pdp["tmp_name"], $photo_pdp_path)) {
                throw new Exception("Erreur lors du téléchargement de la photo de profil.");
            }
            $photo_pdp_path = "uploads/" . $pdp_filename; // chemin pour base de données
        } else {
            throw new Exception("La photo de profil est obligatoire.");
        }

        // Traitement de la photo de voiture (optionnelle)
        $photo_voiture_path = null;
        if ($photo_voiture && $photo_voiture['error'] === UPLOAD_ERR_OK) {
            $voiture_filename = uniqid() . "_" . basename($photo_voiture["name"]);
            $voiture_path = $uploadDir . $voiture_filename;
            if (!move_uploaded_file($photo_voiture["tmp_name"], $voiture_path)) {
                throw new Exception("Erreur lors du téléchargement de la photo de voiture.");
            }
            $photo_voiture_path = "uploads/" . $voiture_filename;
        }

        // Insertion en base de données
        $stmt = $pdo->prepare("INSERT INTO utilisateurs (cin, nom, prenom, email, mot_de_passe, telephone, photo_pdp, photo_voiture) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $cin,
            $nom,
            $prenom,
            $email,
            password_hash($motdepasse, PASSWORD_BCRYPT),
            $telephone,
            $photo_pdp_path,
            $photo_voiture_path
        ]);
        $success = "Inscription réussie !";
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            $error = "Un utilisateur avec ce CIN ou cet email existe déjà.";
        } else {
            $error = "Erreur : " . $e->getMessage();
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
    <style>
        body {
            background: url('background1.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }

        .form-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(255, 224, 24, 0.9);
            width: 400px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="email"], input[type="password"], input[type="tel"], input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .error, .success {
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 15px;
        }

        .error {
            background-color: #fdd;
            color: #a00;
        }

        .success {
            background-color: #dfd;
            color: #070;
        }

        button {
            background: #f3ab25;
            color: white;
            padding: 10px;
            width: 100%;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }

        button:hover {
            background: #ead40f;
        }

        .login-link {
            text-align: center;
            margin-top: 10px;
        }

        .login-link a {
            color: #f3ab25;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Inscription</h2>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($success): ?>
            <div class="success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" id="form">
            <div class="form-group">
                <label for="nom">Nom:</label>
                <input type="text" name="nom" id="nom" required>
            </div>
            <div class="form-group">
                <label for="prenom">Prénom:</label>
                <input type="text" name="prenom" id="prenom" required>
            </div>
            <div class="form-group">
                <label for="cin">CIN:</label>
                <input type="text" name="cin" id="cin" maxlength="8" required>
            </div>
            <div class="form-group">
                <label for="email">Adresse Email:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="form-group">
                <label for="motdepasse">Mot de passe:</label>
                <input type="password" name="motdepasse" id="motdepasse" minlength="8" required>
            </div>
            <div class="form-group">
                <label for="telephone">Téléphone:</label>
                <input type="tel" name="telephone" id="telephone" pattern="\d{8}" maxlength="8" required>

            </div>
            <div class="form-group">
                <label for="photo_voiture">Photo de voiture (optionnelle):</label>
                <input type="file" name="photo_voiture" accept="image/*">
            </div>
            <div class="form-group">
                <label for="photo_pdp">Photo de profil:</label>
                <input type="file" name="photo_pdp" accept="image/*" required>
            </div>
            <button type="submit">S'inscrire</button>
            <div class="login-link">
                Déjà inscrit ? <a href="login.php">Connexion</a>
            </div>
        </form>
    </div>

    <script>
        document.getElementById("form").addEventListener("submit", function(e) {
            let cin = document.getElementById("cin").value;
            if (!/^\d{8}$/.test(cin)) {
                alert("Le CIN doit contenir exactement 8 chiffres.");
                e.preventDefault();
            }
        });
           
    </script>
</body>
</html>
