<?php
session_start();

if (!isset($_SESSION['cin'])) {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "covoiturage");
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

$cin = $_SESSION['cin'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $telephone = $_POST['telephone'];
    $mot_de_passe = $_POST['mot_de_passe'];
    $photo_pdp = $_FILES['photo_pdp'];

    if (!empty($mot_de_passe)) {
        $mot_de_passe_hash = password_hash($mot_de_passe, PASSWORD_BCRYPT);
    }

    if (!empty($photo_pdp['name'])) {
        $photo_nom = basename($photo_pdp['name']);
        $dossier = "uploads/";
        move_uploaded_file($photo_pdp['tmp_name'], $dossier . $photo_nom);
    }

    $sql = "UPDATE utilisateurs SET nom=?, prenom=?, email=?, telephone=?";
    $params = [$nom, $prenom, $email, $telephone];

    if (!empty($mot_de_passe)) {
        $sql .= ", mot_de_passe=?";
        $params[] = $mot_de_passe_hash;
    }

    if (!empty($photo_pdp['name'])) {
        $sql .= ", photo_pdp=?";
        $params[] = $photo_nom;
    }

    $sql .= " WHERE cin=?";
    $params[] = $cin;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(str_repeat("s", count($params)), ...$params);
    $stmt->execute();
    $stmt->close();

    // ✅ Redirection avec succès
    header("Location: modification.php?success=1");
    exit();
}

$sql = "SELECT nom, prenom, email, telephone FROM utilisateurs WHERE cin=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $cin);
$stmt->execute();
$result = $stmt->get_result();
$utilisateur = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier mes informations</title>
    <style>
        body {
            background-image: url('background1.jpg');
            background:rgb(228, 195, 50);
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        form {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            width: 350px;
        }
        input[type="text"], input[type="email"], input[type="password"], input[type="file"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #FFC107;
            color: white;
            padding: 10px;
            width: 100%;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #e6b800;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
            text-align: center;
        }
    </style>
</head>
<body>
    <form method="POST" enctype="multipart/form-data">
        <h2>Modifier mes informations</h2>

        <?php if (isset($_GET['success'])): ?>
            <div class="success">✅ Modification effectuée avec succès.</div>
        <?php endif; ?>

        <input type="text" name="nom" placeholder="Nom" value="<?php echo htmlspecialchars($utilisateur['nom']); ?>" required>
        <input type="text" name="prenom" placeholder="Prénom" value="<?php echo htmlspecialchars($utilisateur['prenom']); ?>" required>
        <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($utilisateur['email']); ?>" required>
        <input type="text" name="telephone" placeholder="Téléphone" value="<?php echo htmlspecialchars($utilisateur['telephone']); ?>" required>
        <input type="password" name="mot_de_passe" placeholder="Nouveau mot de passe (facultatif)">
        <input type="file" name="photo_pdp">
        <button type="submit">Enregistrer</button>
    </form>
</body>
</html>
