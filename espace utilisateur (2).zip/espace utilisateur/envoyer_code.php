<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'lib/PHPMailer/src/Exception.php';
require 'lib/PHPMailer/src/PHPMailer.php';
require 'lib/PHPMailer/src/SMTP.php';

session_start();
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['envoyer_code'])) {
    $email = trim($_POST['email']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Adresse email invalide.";
    } else {
        $code = rand(100000, 999999);
        $_SESSION['code_verification'] = $code;
        $_SESSION['email_verification'] = $email;

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'ton.email@gmail.com'; // Ton email Gmail
            $mail->Password = 'ton_mot_de_passe_application'; // Mot de passe d'application
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('ton.email@gmail.com', 'Ton Nom');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Code de réinitialisation';
            $mail->Body = "Voici votre code de vérification : <strong>$code</strong>";

            $mail->send();
            $message = "Code envoyé avec succès à $email";
        } catch (Exception $e) {
            $message = "Erreur lors de l'envoi de l'email : " . $mail->ErrorInfo;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Envoyer un code</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 300px;
        }
        .form-container h2 {
            text-align: center;
            color: #fbb000;
        }
        .form-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        .form-container button {
            background: #fbb000;
            border: none;
            color: white;
            padding: 10px;
            width: 100%;
            cursor: pointer;
        }
        .success-message {
            color: green;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Mot de passe oublié</h2>
        <form method="POST">
            <input type="email" name="email" placeholder="Votre email" required>
            <button type="submit" name="envoyer_code">Envoyer le code</button>
        </form>
        <?php if (!empty($message)): ?>
            <div class="success-message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
