<?php
session_start();

if (!isset($_SESSION['cin'])) {
    header("Location: login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "covoiturage");
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

$cin = $_SESSION['cin'];
$sql = "SELECT nom, prenom, email, telephone, photo_pdp FROM utilisateurs WHERE cin=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $cin);
$stmt->execute();
$result = $stmt->get_result();
$utilisateur = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Profil Utilisateur</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #fff176, #ffee58);
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .profil-box {
            background-color: #fff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            width: 400px;
        }

        .profil-box img {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid #fdd835;
            margin-bottom: 20px;
        }

        .profil-box h2 {
            color: #fbc02d;
            margin-bottom: 20px;
        }

        .profil-box p {
            font-size: 16px;
            color: #333;
            margin: 10px 0;
        }

        .profil-box strong {
            color: #000;
        }

        .btn-modifier {
            margin-top: 25px;
            padding: 12px 25px;
            font-size: 16px;
            background-color: #fbc02d;
            border: none;
            border-radius: 10px;
            color: #fff;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn-modifier:hover {
            background-color: #f9a825;
        }
    </style>
</head>
<body>
    <div class="profil-box">
        <img src="uploads../<?php echo htmlspecialchars($utilisateur['photo_pdp']); ?>" alt="Photo de profil">
        <h2>Mon Compte</h2>
        <p><strong>Nom :</strong> <?php echo htmlspecialchars($utilisateur['nom']); ?></p>
        <p><strong>Prénom :</strong> <?php echo htmlspecialchars($utilisateur['prenom']); ?></p>
        <p><strong>Email :</strong> <?php echo htmlspecialchars($utilisateur['email']); ?></p>
        <p><strong>Téléphone :</strong> <?php echo htmlspecialchars($utilisateur['telephone']); ?></p>
        <a href="modification.php"><button class="btn-modifier">Modifier mes informations</button></a>
    </div>
</body>
</html>
