<?php
session_start();

// Vérification de la connexion de l'utilisateur
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Stockage de l'email pour affichage
$email = htmlspecialchars($_SESSION['email']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interface Utilisateur</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8e05a;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 400px;
            width: 100%;
            animation: fadeIn 1s ease-in-out;
        }

        h2 {
            color: #FFC107;
            font-size: 1.8em;
            margin-bottom: 20px;
            animation: slideIn 1s ease-in-out;
        }

        .options {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .option {
            background-color: #FFC107;
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
            text-decoration: none;
            display: block;
        }

        .option:hover {
            background-color: #FFD54F;
            transform: translateY(-5px);
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @media (max-width: 480px) {
            .container {
                padding: 20px;
            }

            .options {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Bienvenue, <?= $email ?> !</h2>
        <div class="options">
            <a href="utilisateur.php" class="option">👤 Mon compte</a>
            <a href="publiez_un_trajet.php" class="option">🚗 Publier un trajet</a>
            <a href="chercher_un_trajet.php" class="option">🔍 Rechercher un trajet</a>
            <a href="parrainage.php" class="option">👥 Parrainer un ami</a>
            <a href="points_recompense.php" class="option">🎯 Suivre la progression</a>
            <a href="contact.php" class="option">✉️ Contact</a>
            <a href="chat.php" class="option">💬 Chat</a>
            <a href="logout.php" class="option">🚪 Déconnexion</a>
        </div>
    </div>
</body>
</html>
